import type { Metadata } from "next";
import { isAuthed } from "@/lib/auth";
import { AdminLogin } from "@/components/AdminLogin";
import { AdminDashboard } from "@/components/AdminDashboard";

export const metadata: Metadata = {
  title: "Administração",
  robots: { index: false, follow: false }
};

// Renderiza dinamicamente porque a decisão depende do cookie de sessão.
export const dynamic = "force-dynamic";

export default function AdminPage() {
  if (!isAuthed()) {
    return <AdminLogin />;
  }
  return <AdminDashboard />;
}
