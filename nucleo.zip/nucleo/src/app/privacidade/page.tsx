import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { Footer } from "@/components/Footer";
import { brand } from "@/config/brand";

export const metadata: Metadata = { title: "Política de privacidade" };

export default function Privacy() {
  return (
    <>
      <SiteHeader />
      <main className="container-tight max-w-3xl py-16 sm:py-24">
        <p className="eyebrow">Privacidade e LGPD</p>
        <h1 className="mt-4 text-4xl text-ink dark:text-white">Política de privacidade</h1>
        <p className="mt-3 text-sm text-slate-muted">Modelo inicial — revise com apoio jurídico antes de publicar.</p>

        <div className="mt-10 space-y-8 text-[15px] leading-relaxed text-slate-muted">
          <section>
            <h2 className="text-xl text-ink dark:text-white">Quais dados coletamos</h2>
            <p className="mt-2">Nome completo e data de nascimento (para gerar a análise) e, se você optar por receber o relatório, nome, e-mail e WhatsApp.</p>
          </section>
          <section>
            <h2 className="text-xl text-ink dark:text-white">Para que usamos</h2>
            <p className="mt-2">Gerar e enviar seu relatório, medir o desempenho do site (com seu consentimento) e, quando autorizado, entrar em contato para oferecer acompanhamento.</p>
          </section>
          <section>
            <h2 className="text-xl text-ink dark:text-white">Base legal e consentimento</h2>
            <p className="mt-2">Tratamos seus dados com base no seu consentimento, nos termos da LGPD (Lei 13.709/2018). Cookies de medição só são carregados após você aceitar.</p>
          </section>
          <section>
            <h2 className="text-xl text-ink dark:text-white">Seus direitos</h2>
            <p className="mt-2">Você pode solicitar acesso, correção ou exclusão dos seus dados a qualquer momento pelo e-mail <a className="text-azure underline underline-offset-2" href={`mailto:${brand.email}`}>{brand.email}</a>.</p>
          </section>
          <section>
            <h2 className="text-xl text-ink dark:text-white">Aviso importante</h2>
            <p className="mt-2">{brand.disclaimer}</p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
