import { Suspense } from "react";
import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { Footer } from "@/components/Footer";
import { ResultClient } from "@/components/ResultClient";

export const metadata: Metadata = {
  title: "Sua prévia",
  robots: { index: false, follow: false } // páginas de funil não são indexadas
};

export default function ResultPage() {
  return (
    <>
      <SiteHeader />
      <main>
        <Suspense fallback={<p className="container-tight py-32 text-center text-slate-muted">Carregando…</p>}>
          <ResultClient />
        </Suspense>
      </main>
      <Footer />
    </>
  );
}
