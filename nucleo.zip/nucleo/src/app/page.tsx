import Link from "next/link";
import { brand } from "@/config/brand";
import { SiteHeader } from "@/components/SiteHeader";
import { Footer } from "@/components/Footer";
import { DataForm } from "@/components/DataForm";
import { PatternVisual } from "@/components/PatternVisual";

const steps = [
  { n: "01", title: "Informe seus dados", body: "Nome completo e data de nascimento. Nada além disso." },
  { n: "02", title: "Receba uma prévia", body: "Em segundos, três padrões personalizados e as perguntas que eles levantam." },
  { n: "03", title: "Escolha o relatório completo", body: "Se quiser ir fundo, enviamos a análise inteira em PDF por e-mail." }
];

const questions = [
  "Por que assumo responsabilidades demais?",
  "Por que determinados conflitos se repetem?",
  "Quais características aparecem naturalmente em mim?",
  "Quais padrões podem estar limitando meu desenvolvimento?"
];

// PLACEHOLDERS ILUSTRATIVOS — substitua por depoimentos reais e
// autorizados antes de publicar. Ver nota no README sobre CDC/CONAR.
const testimonials = [
  { quote: "Não esperava me reconhecer tanto em três parágrafos. Uma das perguntas ficou comigo por dias.", who: "R. M." },
  { quote: "Gostei justamente por não prometer verdades absolutas. Me fez pensar, não obedecer.", who: "C. A." },
  { quote: "Elegante e direto. Li a prévia, quis o relatório inteiro na hora.", who: "J. P." }
];

const faqs = [
  { q: "Isto é um teste psicológico?", a: "Não. É uma ferramenta de autoconhecimento e reflexão. Não diagnostica, não avalia clinicamente e não substitui um profissional." },
  { q: "É astrologia?", a: "Não. Não trabalhamos com signos, mapas astrais ou previsões. A leitura parte apenas do seu nome e da sua data de nascimento como pontos de partida para reflexão." },
  { q: "Preciso pagar para ver a prévia?", a: "Não. A prévia com três padrões é gratuita e não exige cadastro. O relatório completo também é enviado sem custo, por e-mail." },
  { q: "O que vocês fazem com meus dados?", a: "Guardamos apenas o necessário para gerar e enviar seu relatório, sempre com seu consentimento, conforme a LGPD. Você pode pedir a exclusão quando quiser." }
];

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main>
        {/* HERO */}
        <section className="relative overflow-hidden">
          <div className="container-tight grid items-center gap-12 py-16 sm:py-24 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
            <div className="reveal">
              <p className="eyebrow">Autoconhecimento, sem misticismo</p>
              <h1 className="mt-5 text-4xl leading-[1.08] text-ink dark:text-white sm:text-5xl lg:text-[3.4rem]">
                Descubra padrões da sua personalidade que talvez você nunca tenha percebido.
              </h1>
              <p className="mt-6 max-w-measure text-lg leading-relaxed text-slate-muted">
                Uma análise personalizada baseada no seu nome completo e data de nascimento para
                estimular autoconhecimento e novas perspectivas.
              </p>
              <div className="mt-8 flex flex-wrap items-center gap-4 text-sm text-slate-muted">
                <span className="inline-flex items-center gap-2"><Dot /> Prévia gratuita</span>
                <span className="inline-flex items-center gap-2"><Dot /> Menos de 1 minuto</span>
                <span className="inline-flex items-center gap-2"><Dot /> Sem promessas absolutas</span>
              </div>
            </div>

            {/* Cartão do formulário + assinatura visual */}
            <div id="descobrir" className="reveal">
              <div className="relative rounded-3xl border hairline bg-white p-6 shadow-xl shadow-ink/5 dark:bg-ink-800 sm:p-8">
                <div className="pointer-events-none absolute -right-6 -top-10 opacity-70">
                  <PatternVisual size={180} />
                </div>
                <h2 className="font-display text-xl text-ink dark:text-white">Sua prévia personalizada</h2>
                <p className="mt-1 mb-6 text-sm text-slate-muted">Comece pelos seus dados.</p>
                <DataForm />
              </div>
            </div>
          </div>
        </section>

        {/* COMO FUNCIONA */}
        <section id="como-funciona" className="border-t hairline bg-[#FAFBFC] py-20 dark:bg-ink-800/40">
          <div className="container-tight">
            <p className="eyebrow">Como funciona</p>
            <h2 className="mt-4 max-w-2xl text-3xl text-ink dark:text-white sm:text-4xl">Três passos. Nada de complicação.</h2>
            <div className="mt-12 grid gap-8 sm:grid-cols-3">
              {steps.map((s) => (
                <div key={s.n} className="border-t-2 border-ink pt-5 dark:border-white/70">
                  <span className="font-display text-3xl text-azure">{s.n}</span>
                  <h3 className="mt-3 text-lg text-ink dark:text-white">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-muted">{s.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* PERGUNTAS QUE O RELATÓRIO RESPONDE */}
        <section className="py-20">
          <div className="container-tight grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:items-center">
            <div>
              <p className="eyebrow">O que ele levanta</p>
              <h2 className="mt-4 text-3xl text-ink dark:text-white sm:text-4xl">Perguntas que o relatório ajuda a enxergar.</h2>
              <p className="mt-5 max-w-measure text-slate-muted">
                Não entregamos respostas prontas. Entregamos boas perguntas — que costumam ser mais úteis.
              </p>
            </div>
            <ul className="grid gap-px overflow-hidden rounded-2xl border hairline bg-hair dark:bg-white/10 sm:grid-cols-2">
              {questions.map((q) => (
                <li key={q} className="bg-white p-7 dark:bg-ink-800">
                  <p className="font-display text-lg leading-snug text-ink dark:text-white">"{q}"</p>
                </li>
              ))}
            </ul>
          </div>
        </section>

        {/* DEPOIMENTOS (placeholders ilustrativos) */}
        <section className="border-t hairline bg-[#FAFBFC] py-20 dark:bg-ink-800/40">
          <div className="container-tight">
            <div className="flex items-baseline justify-between gap-4">
              <div>
                <p className="eyebrow">Impressões</p>
                <h2 className="mt-4 text-3xl text-ink dark:text-white sm:text-4xl">O que as pessoas dizem.</h2>
              </div>
              <span className="hidden text-xs uppercase tracking-eyebrow text-slate-muted sm:block">Exemplos ilustrativos</span>
            </div>
            <div className="mt-12 grid gap-6 sm:grid-cols-3">
              {testimonials.map((t, i) => (
                <figure key={i} className="rounded-2xl border hairline bg-white p-7 dark:bg-ink-800">
                  <blockquote className="text-[15px] leading-relaxed text-ink dark:text-slate-100">"{t.quote}"</blockquote>
                  <figcaption className="mt-5 text-sm font-medium text-slate-muted">{t.who}</figcaption>
                </figure>
              ))}
            </div>
            <p className="mt-6 text-xs text-slate-muted">Depoimentos ilustrativos para demonstração. Substitua por relatos reais e autorizados antes de publicar.</p>
          </div>
        </section>

        {/* FAQ */}
        <section id="perguntas" className="py-20">
          <div className="container-tight grid gap-12 lg:grid-cols-[0.7fr_1.3fr]">
            <div>
              <p className="eyebrow">Dúvidas</p>
              <h2 className="mt-4 text-3xl text-ink dark:text-white sm:text-4xl">Perguntas frequentes.</h2>
            </div>
            <div className="divide-y hairline border-y hairline">
              {faqs.map((f) => (
                <details key={f.q} className="group py-5">
                  <summary className="flex cursor-pointer list-none items-center justify-between text-lg text-ink dark:text-white">
                    {f.q}
                    <span className="ml-4 text-azure transition-transform group-open:rotate-45">+</span>
                  </summary>
                  <p className="mt-3 max-w-measure text-[15px] leading-relaxed text-slate-muted">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* CTA final */}
        <section className="border-t hairline py-20">
          <div className="container-tight text-center">
            <h2 className="mx-auto max-w-2xl text-3xl text-ink dark:text-white sm:text-4xl">
              Talvez o padrão que te trava seja o mesmo que você mais admira em si.
            </h2>
            <p className="mx-auto mt-5 max-w-md text-slate-muted">Comece pela prévia gratuita. Você decide o resto.</p>
            <Link href="/#descobrir" className="btn-primary mt-8">{brand.cta.primary}</Link>
          </div>
        </section>

        {/* Aviso discreto */}
        <div className="container-tight pb-16">
          <p className="mx-auto max-w-measure text-center text-xs leading-relaxed text-slate-muted">{brand.disclaimer}</p>
        </div>
      </main>
      <Footer />
    </>
  );
}

function Dot() {
  return <span className="inline-block h-1.5 w-1.5 rounded-full bg-azure" />;
}
