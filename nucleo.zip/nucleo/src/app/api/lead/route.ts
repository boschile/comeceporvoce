import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { renderReportPDF } from "@/lib/pdf";
import { sendReportEmail } from "@/lib/email";
import { sendLeadEvent } from "@/lib/capi";

export const runtime = "nodejs";

function clientIp(req: NextRequest): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req: NextRequest) {
  let data: any;
  try {
    data = await req.json();
  } catch {
    return NextResponse.json({ error: "Requisição inválida." }, { status: 400 });
  }

  const { leadId, contactName, email, whatsapp, consent, honeypot, eventId } = data || {};

  if (honeypot) return NextResponse.json({ error: "Não foi possível processar." }, { status: 400 });
  if (!leadId) return NextResponse.json({ error: "Sessão expirada. Refaça a análise." }, { status: 422 });
  if (!consent) return NextResponse.json({ error: "É necessário aceitar os termos." }, { status: 422 });
  if (!EMAIL_RE.test(String(email || ""))) {
    return NextResponse.json({ error: "Informe um e-mail válido." }, { status: 422 });
  }

  const lead = await prisma.lead.findUnique({ where: { id: String(leadId) } });
  if (!lead) return NextResponse.json({ error: "Registro não encontrado." }, { status: 404 });

  // Gera o PDF e tenta enviar por e-mail (degrada se SMTP não estiver setado).
  let emailSent = false;
  try {
    const pdf = await renderReportPDF({ fullName: lead.fullName, birthDate: lead.birthDate });
    const firstName = (contactName || lead.fullName).trim().split(/\s+/)[0];
    const res = await sendReportEmail({ to: email, firstName, pdf });
    emailSent = res.sent;
  } catch (e) {
    console.error("[lead] falha ao gerar/enviar relatório:", e);
  }

  await prisma.lead.update({
    where: { id: lead.id },
    data: {
      stage: "CAPTURED",
      contactName: contactName ? String(contactName).slice(0, 120) : null,
      email: String(email).slice(0, 160),
      whatsapp: whatsapp ? String(whatsapp).slice(0, 40) : null,
      consent: true,
      reportSentAt: emailSent ? new Date() : null
    }
  });

  // Conversão server-side (Meta CAPI), deduplicada com o Pixel via eventId.
  await sendLeadEvent({
    email,
    phone: whatsapp,
    eventId: String(eventId || lead.id),
    clientIp: clientIp(req),
    userAgent: req.headers.get("user-agent") || undefined,
    sourceUrl: req.headers.get("referer") || undefined
  });

  return NextResponse.json({ ok: true, emailSent });
}
