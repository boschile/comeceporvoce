import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAuthed } from "@/lib/auth";
import { toCSV } from "@/lib/csv";

export const runtime = "nodejs";

export async function GET() {
  if (!isAuthed()) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const leads = await prisma.lead.findMany({ orderBy: { createdAt: "desc" } });
  const rows = leads.map((l) => ({
    id: l.id,
    etapa: l.stage,
    nome_analise: l.fullName,
    nascimento: l.birthDate,
    contato: l.contactName || "",
    email: l.email || "",
    whatsapp: l.whatsapp || "",
    caminho_de_vida: l.lifePath,
    expressao: l.expression,
    alma: l.soulUrge,
    personalidade: l.personality,
    contatado: l.contacted ? "sim" : "nao",
    relatorio_enviado: l.reportSentAt ? l.reportSentAt.toISOString() : "",
    origem: l.source || "",
    criado_em: l.createdAt.toISOString()
  }));
  const csv = toCSV(rows);
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="leads-nucleo-${new Date().toISOString().slice(0, 10)}.csv"`
    }
  });
}
