import { NextRequest, NextResponse } from "next/server";
import { checkPassword, setSession, clearSession } from "@/lib/auth";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const { password } = await req.json().catch(() => ({}));
  if (!checkPassword(String(password || ""))) {
    return NextResponse.json({ error: "Senha incorreta." }, { status: 401 });
  }
  setSession();
  return NextResponse.json({ ok: true });
}

export async function DELETE() {
  clearSession();
  return NextResponse.json({ ok: true });
}
