import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAuthed } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  if (!isAuthed()) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const [partial, captured, reportsSent, contacted] = await Promise.all([
    prisma.lead.count({ where: { stage: "PARTIAL" } }),
    prisma.lead.count({ where: { stage: "CAPTURED" } }),
    prisma.lead.count({ where: { reportSentAt: { not: null } } }),
    prisma.lead.count({ where: { contacted: true } })
  ]);

  const total = partial + captured;
  const captureRate = total ? captured / total : 0; // prévia -> captura
  const contactRate = captured ? contacted / captured : 0;

  // Série dos últimos 14 dias.
  const since = new Date(Date.now() - 13 * 864e5);
  const recent = await prisma.lead.findMany({
    where: { createdAt: { gte: since } },
    select: { createdAt: true, stage: true }
  });
  const byDay: Record<string, { previews: number; captures: number }> = {};
  for (let i = 0; i < 14; i++) {
    const key = new Date(Date.now() - (13 - i) * 864e5).toISOString().slice(0, 10);
    byDay[key] = { previews: 0, captures: 0 };
  }
  for (const l of recent) {
    const key = l.createdAt.toISOString().slice(0, 10);
    if (!byDay[key]) continue;
    byDay[key].previews++;
    if (l.stage === "CAPTURED") byDay[key].captures++;
  }

  return NextResponse.json({
    totals: { previews: total, captured, reportsSent, contacted },
    rates: { captureRate, contactRate },
    series: Object.entries(byDay).map(([date, v]) => ({ date, ...v }))
  });
}
