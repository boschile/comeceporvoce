import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAuthed } from "@/lib/auth";
import { renderReportPDF } from "@/lib/pdf";
import { sendReportEmail } from "@/lib/email";

export const runtime = "nodejs";

export async function POST(_req: Request, { params }: { params: { id: string } }) {
  if (!isAuthed()) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const lead = await prisma.lead.findUnique({ where: { id: params.id } });
  if (!lead || !lead.email) return NextResponse.json({ error: "Lead sem e-mail." }, { status: 422 });

  const pdf = await renderReportPDF({ fullName: lead.fullName, birthDate: lead.birthDate });
  const res = await sendReportEmail({
    to: lead.email,
    firstName: (lead.contactName || lead.fullName).split(/\s+/)[0],
    pdf
  });
  if (res.sent) {
    await prisma.lead.update({ where: { id: lead.id }, data: { reportSentAt: new Date() } });
  }
  return NextResponse.json({ sent: res.sent, reason: res.reason });
}
