import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAuthed } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  if (!isAuthed()) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();
  const stage = searchParams.get("stage");
  const contacted = searchParams.get("contacted");

  const where: any = {};
  if (stage && stage !== "ALL") where.stage = stage;
  if (contacted === "true") where.contacted = true;
  if (contacted === "false") where.contacted = false;
  if (q) {
    where.OR = [
      { fullName: { contains: q } },
      { email: { contains: q } },
      { whatsapp: { contains: q } },
      { contactName: { contains: q } }
    ];
  }

  const leads = await prisma.lead.findMany({ where, orderBy: { createdAt: "desc" }, take: 500 });
  return NextResponse.json({ leads });
}
