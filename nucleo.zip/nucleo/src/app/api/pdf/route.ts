import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { isAuthed } from "@/lib/auth";
import { renderReportPDF } from "@/lib/pdf";

export const runtime = "nodejs";

// Download do PDF de um lead. Protegido: só admin autenticado.
export async function GET(req: NextRequest) {
  if (!isAuthed()) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const id = new URL(req.url).searchParams.get("lead");
  if (!id) return NextResponse.json({ error: "missing lead" }, { status: 400 });
  const lead = await prisma.lead.findUnique({ where: { id } });
  if (!lead) return NextResponse.json({ error: "not_found" }, { status: 404 });

  const pdf = await renderReportPDF({ fullName: lead.fullName, birthDate: lead.birthDate });
  return new NextResponse(new Uint8Array(pdf), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `inline; filename="relatorio-${lead.id}.pdf"`
    }
  });
}
