import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { buildPreview } from "@/lib/numerology";

export const runtime = "nodejs";

function clientIp(req: NextRequest): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

export async function POST(req: NextRequest) {
  let data: any;
  try {
    data = await req.json();
  } catch {
    return NextResponse.json({ error: "Requisição inválida." }, { status: 400 });
  }

  const { fullName, birthDate, honeypot, startedAt, utm, source } = data || {};

  // Anti-spam silencioso: campo isca + tempo mínimo de preenchimento.
  if (honeypot) return NextResponse.json({ error: "Não foi possível processar." }, { status: 400 });
  if (startedAt && Date.now() - Number(startedAt) < 1200) {
    return NextResponse.json({ error: "Aguarde um instante e tente novamente." }, { status: 429 });
  }

  const name = String(fullName || "").trim();
  const date = String(birthDate || "").trim();

  if (name.split(/\s+/).length < 2 || name.length < 3) {
    return NextResponse.json({ error: "Informe seu nome completo." }, { status: 422 });
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
    return NextResponse.json({ error: "Informe uma data de nascimento válida." }, { status: 422 });
  }
  const d = new Date(date);
  if (isNaN(d.getTime()) || d > new Date() || d.getUTCFullYear() < 1900) {
    return NextResponse.json({ error: "Informe uma data de nascimento válida." }, { status: 422 });
  }

  const preview = buildPreview(name, date);

  const lead = await prisma.lead.create({
    data: {
      stage: "PARTIAL",
      fullName: name,
      birthDate: date,
      lifePath: preview.numbers.lifePath,
      expression: preview.numbers.expression,
      soulUrge: preview.numbers.soulUrge,
      personality: preview.numbers.personality,
      previewJson: JSON.stringify(preview),
      source: source ? String(source).slice(0, 120) : null,
      utm: utm ? JSON.stringify(utm).slice(0, 500) : null,
      ip: clientIp(req),
      userAgent: req.headers.get("user-agent")?.slice(0, 300) || null
    }
  });

  return NextResponse.json({ leadId: lead.id, preview });
}
