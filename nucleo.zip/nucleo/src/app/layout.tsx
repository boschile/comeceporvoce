import type { Metadata } from "next";
import { Fraunces, Inter } from "next/font/google";
import "./globals.css";
import { brand, siteUrl } from "@/config/brand";
import { Analytics } from "@/components/Analytics";
import { CookieBanner } from "@/components/CookieBanner";

const display = Fraunces({
  subsets: ["latin"],
  weight: ["400", "500"],
  style: ["normal", "italic"],
  variable: "--font-display",
  display: "swap"
});
const sans = Inter({ subsets: ["latin"], variable: "--font-sans", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${brand.name} — ${brand.tagline}`,
    template: `%s · ${brand.name}`
  },
  description:
    "Uma análise personalizada baseada no seu nome completo e data de nascimento para estimular autoconhecimento e novas perspectivas.",
  keywords: ["autoconhecimento", "perfil", "reflexão", "desenvolvimento pessoal"],
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: siteUrl,
    siteName: brand.name,
    title: `${brand.name} — ${brand.tagline}`,
    description:
      "Descubra padrões da sua personalidade que talvez você nunca tenha percebido.",
    images: [{ url: "/og.png", width: 1200, height: 630, alt: brand.name }]
  },
  twitter: {
    card: "summary_large_image",
    title: `${brand.name} — ${brand.tagline}`,
    description: "Descubra padrões da sua personalidade que talvez você nunca tenha percebido."
  },
  robots: { index: true, follow: true },
  alternates: { canonical: siteUrl }
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "WebApplication",
  name: brand.name,
  applicationCategory: "LifestyleApplication",
  operatingSystem: "Web",
  offers: { "@type": "Offer", price: "0", priceCurrency: "BRL" },
  description:
    "Ferramenta de autoconhecimento que gera uma prévia personalizada a partir do nome e da data de nascimento."
};

// Evita flash de tema errado: aplica a classe antes da hidratação.
const themeScript = `(function(){try{var t=localStorage.getItem('theme');var d=t?t==='dark':window.matchMedia('(prefers-color-scheme:dark)').matches;if(d)document.documentElement.classList.add('dark');}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR" className={`${display.variable} ${sans.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      </head>
      <body className="bg-white text-ink antialiased dark:bg-ink-900 dark:text-slate-100">
        <Analytics />
        {children}
        <CookieBanner />
      </body>
    </html>
  );
}
