import type { Metadata } from "next";
import Link from "next/link";
import { SiteHeader } from "@/components/SiteHeader";
import { Footer } from "@/components/Footer";
import { PatternVisual } from "@/components/PatternVisual";
import { brand, whatsappNumber } from "@/config/brand";

export const metadata: Metadata = { title: "Relatório a caminho", robots: { index: false, follow: false } };

export default function ThankYou() {
  const wpp = whatsappNumber
    ? `https://wa.me/${whatsappNumber}?text=${encodeURIComponent("Recebi meu relatório e quero conversar sobre ele.")}`
    : null;
  return (
    <>
      <SiteHeader />
      <main className="container-tight flex min-h-[70vh] flex-col items-center justify-center py-20 text-center">
        <PatternVisual size={200} />
        <p className="eyebrow mt-6">Tudo certo</p>
        <h1 className="mt-4 max-w-2xl text-3xl text-ink dark:text-white sm:text-4xl">
          Seu relatório completo está a caminho do seu e-mail.
        </h1>
        <p className="mt-5 max-w-md text-slate-muted">
          Confira também a caixa de spam ou promoções. Reserve alguns minutos sem pressa para a leitura.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {wpp && <a href={wpp} target="_blank" className="btn-primary">Conversar no WhatsApp</a>}
          <Link href="/" className="btn-ghost">Voltar ao início</Link>
        </div>
        <p className="mx-auto mt-14 max-w-measure text-xs leading-relaxed text-slate-muted">{brand.disclaimer}</p>
      </main>
      <Footer />
    </>
  );
}
