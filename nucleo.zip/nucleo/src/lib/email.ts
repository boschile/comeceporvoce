import nodemailer from "nodemailer";
import { brand, siteUrl } from "@/config/brand";

function transport() {
  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) return null;
  return nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT || 587),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
}

function html(firstName: string): string {
  const name = firstName || "olá";
  return `
  <div style="font-family:Inter,Arial,sans-serif;color:#0C1A2B;max-width:560px;margin:0 auto;padding:8px">
    <p style="font-size:11px;letter-spacing:2px;color:#2E5AAC;text-transform:uppercase;margin:0 0 8px">${brand.name}</p>
    <h1 style="font-family:Georgia,serif;font-size:24px;font-weight:400;margin:0 0 16px">Seu relatório completo chegou, ${name}.</h1>
    <p style="font-size:15px;line-height:1.6;color:#26313f">
      Ele está anexado a este e-mail em PDF. Reserve alguns minutos sem pressa: o material foi feito
      para provocar reflexão, não para ser lido às pressas.
    </p>
    <p style="font-size:15px;line-height:1.6;color:#26313f">
      Se alguma das perguntas continuar ecoando depois da leitura, é um bom sinal — e um bom ponto
      de partida para conversarmos.
    </p>
    <p style="margin-top:24px;font-size:13px;color:#5B6B7B">— Equipe ${brand.name}<br/><a style="color:#2E5AAC" href="${siteUrl}">${brand.domain}</a></p>
    <hr style="border:none;border-top:1px solid #E7E9EE;margin:24px 0"/>
    <p style="font-size:11px;line-height:1.5;color:#5B6B7B">${brand.disclaimer}</p>
  </div>`;
}

export async function sendReportEmail(opts: {
  to: string;
  firstName: string;
  pdf: Buffer;
}): Promise<{ sent: boolean; reason?: string }> {
  const t = transport();
  if (!t) {
    console.warn("[email] SMTP não configurado — pulando envio real para", opts.to);
    return { sent: false, reason: "smtp_not_configured" };
  }
  await t.sendMail({
    from: process.env.SMTP_FROM || `${brand.name} <no-reply@${brand.domain}>`,
    to: opts.to,
    subject: `Seu relatório ${brand.name} está pronto`,
    html: html(opts.firstName),
    attachments: [
      { filename: `relatorio-${brand.name.toLowerCase()}.pdf`, content: opts.pdf, contentType: "application/pdf" }
    ]
  });
  return { sent: true };
}
