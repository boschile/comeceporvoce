import crypto from "crypto";

const sha256 = (v: string) =>
  crypto.createHash("sha256").update(v.trim().toLowerCase()).digest("hex");

// Envia o evento "Lead" para a Meta Conversions API (server-side).
// Sem credenciais, apenas retorna sem erro — o funil segue funcionando.
export async function sendLeadEvent(opts: {
  email?: string | null;
  phone?: string | null;
  eventId: string;
  clientIp?: string;
  userAgent?: string;
  sourceUrl?: string;
}): Promise<void> {
  const pixelId = process.env.META_CAPI_PIXEL_ID;
  const token = process.env.META_CAPI_ACCESS_TOKEN;
  if (!pixelId || !token) return;

  const userData: Record<string, string[] | string> = {};
  if (opts.email) userData.em = [sha256(opts.email)];
  if (opts.phone) userData.ph = [sha256(opts.phone.replace(/\D/g, ""))];
  if (opts.clientIp) userData.client_ip_address = opts.clientIp;
  if (opts.userAgent) userData.client_user_agent = opts.userAgent;

  const body: Record<string, unknown> = {
    data: [
      {
        event_name: "Lead",
        event_time: Math.floor(Date.now() / 1000),
        event_id: opts.eventId, // deduplicação com o Pixel do navegador
        action_source: "website",
        event_source_url: opts.sourceUrl,
        user_data: userData
      }
    ]
  };
  if (process.env.META_CAPI_TEST_CODE) body.test_event_code = process.env.META_CAPI_TEST_CODE;

  try {
    await fetch(`https://graph.facebook.com/v20.0/${pixelId}/events?access_token=${token}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
  } catch (e) {
    console.error("[CAPI] falha ao enviar evento:", e);
  }
}
