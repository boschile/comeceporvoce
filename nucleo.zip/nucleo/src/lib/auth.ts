import { cookies } from "next/headers";
import crypto from "crypto";

const COOKIE = "nucleo_admin";
const secret = () => process.env.ADMIN_SESSION_SECRET || "dev-secret-change-me";

// Token assinado simples (HMAC). Suficiente para um painel de um operador;
// para múltiplos admins, troque por um provedor de sessão dedicado.
export function issueToken(): string {
  const payload = `admin.${Date.now()}`;
  const sig = crypto.createHmac("sha256", secret()).update(payload).digest("hex");
  return `${payload}.${sig}`;
}

export function verifyToken(token?: string): boolean {
  if (!token) return false;
  const idx = token.lastIndexOf(".");
  if (idx < 0) return false;
  const payload = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const expected = crypto.createHmac("sha256", secret()).update(payload).digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
  } catch {
    return false;
  }
}

export function checkPassword(input: string): boolean {
  const expected = process.env.ADMIN_PASSWORD || "";
  if (!expected) return false;
  const a = Buffer.from(input);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function setSession() {
  cookies().set(COOKIE, issueToken(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 8 // 8h
  });
}

export function clearSession() {
  cookies().delete(COOKIE);
}

export function isAuthed(): boolean {
  return verifyToken(cookies().get(COOKIE)?.value);
}

export const ADMIN_COOKIE = COOKIE;
