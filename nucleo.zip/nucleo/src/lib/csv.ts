// Serializa leads para CSV (compatível com Excel/pt-BR, com BOM e ; ).
export function toCSV(rows: Record<string, unknown>[]): string {
  if (rows.length === 0) return "\uFEFF";
  const headers = Object.keys(rows[0]);
  const esc = (v: unknown) => {
    const s = v === null || v === undefined ? "" : String(v);
    return `"${s.replace(/"/g, '""')}"`;
  };
  const lines = [
    headers.join(";"),
    ...rows.map((r) => headers.map((h) => esc(r[h])).join(";"))
  ];
  return "\uFEFF" + lines.join("\r\n");
}
