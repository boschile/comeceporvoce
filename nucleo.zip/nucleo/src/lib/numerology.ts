// ─────────────────────────────────────────────────────────────
//  Motor de leitura (numerologia pitagórica clássica)
//
//  IMPORTANTE — postura honesta:
//  Isto NÃO é um diagnóstico e não tem base científica. É um gerador
//  determinístico de PONTOS DE PARTIDA para reflexão. Toda a redação
//  usa linguagem hedge ("pode indicar", "muitas pessoas relatam") e
//  termina em PERGUNTAS — nunca em afirmações categóricas sobre a
//  pessoa. Mantenha esse tom ao editar os textos.
// ─────────────────────────────────────────────────────────────

const PYTHAGOREAN: Record<string, number> = {
  a: 1, j: 1, s: 1,
  b: 2, k: 2, t: 2,
  c: 3, l: 3, u: 3,
  d: 4, m: 4, v: 4,
  e: 5, n: 5, w: 5,
  f: 6, o: 6, x: 6,
  g: 7, p: 7, y: 7,
  h: 8, q: 8, z: 8,
  i: 9, r: 9
};

const VOWELS = new Set(["a", "e", "i", "o", "u"]);
const MASTERS = new Set([11, 22, 33]);

function normalize(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove acentos
    .toLowerCase()
    .replace(/[^a-z ]/g, "");
}

function reduce(n: number): number {
  while (n > 9 && !MASTERS.has(n)) {
    n = String(n)
      .split("")
      .reduce((s, d) => s + Number(d), 0);
  }
  return n;
}

function sumLetters(text: string, filter?: (ch: string) => boolean): number {
  const total = normalize(text)
    .split("")
    .filter((ch) => PYTHAGOREAN[ch] && (!filter || filter(ch)))
    .reduce((s, ch) => s + PYTHAGOREAN[ch], 0);
  return reduce(total) || 1;
}

export interface Numbers {
  lifePath: number; // data de nascimento
  expression: number; // nome completo
  soulUrge: number; // vogais
  personality: number; // consoantes
}

export function computeNumbers(fullName: string, birthDate: string): Numbers {
  // data ISO yyyy-mm-dd
  const digits = birthDate.replace(/[^0-9]/g, "");
  const lifePath = reduce(
    digits.split("").reduce((s, d) => s + Number(d), 0)
  ) || 1;

  return {
    lifePath,
    expression: sumLetters(fullName),
    soulUrge: sumLetters(fullName, (ch) => VOWELS.has(ch)),
    personality: sumLetters(fullName, (ch) => !VOWELS.has(ch))
  };
}

// ── Biblioteca de significados (tom reflexivo, termina em pergunta) ──
interface Meaning {
  title: string;
  description: string;
  question: string;
}

const LIBRARY: Record<number, Meaning> = {
  1: {
    title: "A tendência a liderar sozinho",
    description:
      "Há um traço de iniciativa e independência forte. Você costuma abrir caminho antes dos outros — e, às vezes, carrega mais do que precisaria.",
    question: "Onde a sua autonomia deixou de ser força e virou peso?"
  },
  2: {
    title: "A leitura fina do ambiente",
    description:
      "Uma sensibilidade para clima e relação que percebe o não dito. Isso conecta pessoas, mas também pode adiar as suas próprias decisões.",
    question: "Quantas escolhas suas ainda esperam a aprovação de alguém?"
  },
  3: {
    title: "A expressão que precisa sair",
    description:
      "Comunicação e criatividade aparecem com naturalidade. O desafio raramente é falar — é sustentar profundidade quando o brilho passa.",
    question: "O que você começa com entusiasmo e não termina?"
  },
  4: {
    title: "A construção pela disciplina",
    description:
      "Método, ordem e persistência formam a sua base. A mesma estrutura que sustenta pode, em excesso, virar rigidez diante do inesperado.",
    question: "Qual regra sua já não serve mais, mas você ainda cumpre?"
  },
  5: {
    title: "A busca por movimento",
    description:
      "Curiosidade e necessidade de liberdade puxam você para o novo. A energia é ampla; o custo costuma ser a constância.",
    question: "O que a sua inquietação está tentando evitar sentir?"
  },
  6: {
    title: "O peso de cuidar",
    description:
      "Responsabilidade pelos outros surge quase como reflexo. Você tende a assumir o que é de todos — e a esquecer de si no processo.",
    question: "De quem é, de verdade, o problema que você resolveu ontem?"
  },
  7: {
    title: "A mente que analisa antes de sentir",
    description:
      "Profundidade e observação marcam o seu jeito. A distância que protege pode, sem querer, virar isolamento.",
    question: "Quando entender virou um jeito de não se envolver?"
  },
  8: {
    title: "A relação com poder e resultado",
    description:
      "Ambição e visão prática de valor caminham juntas. A conta que você faz com dinheiro e conquista às vezes também vira medida do seu valor.",
    question: "O que precisaria acontecer para você se sentir 'suficiente'?"
  },
  9: {
    title: "A entrega ao propósito maior",
    description:
      "Um olhar amplo e generoso, que pensa no todo. O idealismo inspira, mas também dificulta encerrar ciclos e soltar o que já passou.",
    question: "O que você segura porque encerrar parece uma derrota?"
  },
  11: {
    title: "A intensidade que oscila",
    description:
      "Percepção aguçada e picos de energia criativa, alternados com quedas. Você sente com amplitude — e isso cobra um preço de regulação.",
    question: "Como você trata os seus dias baixos: como falha ou como parte?"
  },
  22: {
    title: "A ambição de construir grande",
    description:
      "Visão de longo alcance somada à capacidade de executar. A escala dos seus planos pode adiar indefinidamente o começar.",
    question: "Qual projeto grande virou desculpa para não começar o pequeno?"
  },
  33: {
    title: "O cuidado que se torna missão",
    description:
      "Uma vocação de servir e orientar que mobiliza os outros. O risco é diluir os próprios limites em nome do bem coletivo.",
    question: "Onde termina o seu cuidado e começa a sua ausência de você?"
  }
};

function meaningFor(n: number): Meaning {
  return LIBRARY[n] || LIBRARY[reduce(n)] || LIBRARY[1];
}

export interface Pattern {
  index: number;
  number: number;
  title: string;
  description: string;
  question: string;
}

export interface Preview {
  firstName: string;
  numbers: Numbers;
  patterns: Pattern[]; // exatamente 3 — a amostra gratuita
}

export function buildPreview(fullName: string, birthDate: string): Preview {
  const numbers = computeNumbers(fullName, birthDate);
  const firstName = fullName.trim().split(/\s+/)[0] || "";

  // Os 3 padrões da prévia usam Caminho de Vida, Expressão e Alma.
  const picks = [numbers.lifePath, numbers.expression, numbers.soulUrge];
  const patterns: Pattern[] = picks.map((num, i) => {
    const m = meaningFor(num);
    return {
      index: i + 1,
      number: num,
      title: m.title,
      description: m.description,
      question: m.question
    };
  });

  return { firstName, numbers, patterns };
}

// Conteúdo estendido usado no PDF (relatório completo).
export function buildFullReport(fullName: string, birthDate: string) {
  const { firstName, numbers, patterns } = buildPreview(fullName, birthDate);
  const dimensions = [
    { label: "Caminho de Vida", number: numbers.lifePath, kind: "trajetória e temas recorrentes" },
    { label: "Expressão", number: numbers.expression, kind: "talentos que aparecem naturalmente" },
    { label: "Motivação (Alma)", number: numbers.soulUrge, kind: "o que move por dentro" },
    { label: "Imagem (Personalidade)", number: numbers.personality, kind: "como os outros costumam te ler" }
  ].map((d) => ({ ...d, ...meaningFor(d.number) }));

  return { firstName, fullName, numbers, patterns, dimensions };
}
