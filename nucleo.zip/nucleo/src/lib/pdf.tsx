import React from "react";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  renderToBuffer
} from "@react-pdf/renderer";
import { buildFullReport } from "./numerology";
import { brand } from "@/config/brand";

// Paleta espelhando o site. Usa fontes nativas do PDF (Times/Helvetica),
// portanto não depende de rede para gerar — gera igual em qualquer ambiente.
const NAVY = "#0C1A2B";
const AZURE = "#2E5AAC";
const SLATE = "#5B6B7B";
const HAIR = "#E2E5EC";

const s = StyleSheet.create({
  page: { paddingTop: 64, paddingBottom: 64, paddingHorizontal: 56, fontFamily: "Helvetica", color: NAVY },
  cover: { flexDirection: "column", justifyContent: "space-between", height: "100%", paddingVertical: 40 },
  eyebrow: { fontSize: 9, letterSpacing: 3, color: AZURE, textTransform: "uppercase", fontFamily: "Helvetica-Bold" },
  coverTitle: { fontFamily: "Times-Roman", fontSize: 40, marginTop: 18, lineHeight: 1.1 },
  coverName: { fontFamily: "Times-Italic", fontSize: 22, color: SLATE, marginTop: 24 },
  coverMeta: { fontSize: 10, color: SLATE, marginTop: 6 },
  rule: { height: 1, backgroundColor: HAIR, marginVertical: 18 },
  h2: { fontFamily: "Times-Roman", fontSize: 20, marginBottom: 4 },
  eyebrowSmall: { fontSize: 8, letterSpacing: 2, color: AZURE, textTransform: "uppercase", fontFamily: "Helvetica-Bold", marginBottom: 14 },
  body: { fontSize: 11, lineHeight: 1.6, color: "#26313f" },
  tocItem: { flexDirection: "row", justifyContent: "space-between", marginBottom: 8, fontSize: 11 },
  card: { marginBottom: 20, paddingBottom: 16, borderBottomWidth: 1, borderBottomColor: HAIR },
  cardLabel: { fontSize: 9, letterSpacing: 1.5, color: SLATE, textTransform: "uppercase", fontFamily: "Helvetica-Bold" },
  cardTitle: { fontFamily: "Times-Roman", fontSize: 15, marginTop: 4, marginBottom: 6 },
  num: { fontFamily: "Times-Roman", fontSize: 34, color: AZURE, marginRight: 14 },
  question: { fontFamily: "Times-Italic", fontSize: 12, color: NAVY, marginTop: 8 },
  footer: { position: "absolute", bottom: 30, left: 56, right: 56, fontSize: 7.5, color: SLATE, textAlign: "center", borderTopWidth: 1, borderTopColor: HAIR, paddingTop: 8, lineHeight: 1.5 }
});

function Footer() {
  return <Text style={s.footer} fixed>{brand.disclaimer}</Text>;
}

export interface ReportInput {
  fullName: string;
  birthDate: string;
  generatedAt?: Date;
}

function ReportDoc({ fullName, birthDate, generatedAt = new Date() }: ReportInput) {
  const r = buildFullReport(fullName, birthDate);
  const dateStr = generatedAt.toLocaleDateString("pt-BR", { day: "2-digit", month: "long", year: "numeric" });

  return (
    <Document title={`Relatório ${brand.name} — ${r.fullName}`} author={brand.name}>
      {/* Capa */}
      <Page size="A4" style={s.page}>
        <View style={s.cover}>
          <View>
            <Text style={s.eyebrow}>{brand.name} · Relatório de Autoconhecimento</Text>
            <Text style={s.coverTitle}>Padrões da sua{"\n"}personalidade.</Text>
          </View>
          <View>
            <Text style={s.coverName}>{r.fullName}</Text>
            <Text style={s.coverMeta}>Emitido em {dateStr}</Text>
            <View style={s.rule} />
            <Text style={{ fontSize: 10, color: SLATE, lineHeight: 1.6 }}>{brand.method}</Text>
          </View>
        </View>
        <Footer />
      </Page>

      {/* Sumário + como ler */}
      <Page size="A4" style={s.page}>
        <Text style={s.eyebrowSmall}>Sumário</Text>
        <View style={{ marginBottom: 28 }}>
          {["Como ler este relatório", "As quatro dimensões", "Potenciais e desafios", "Perguntas para reflexão", "Conclusão"].map((t, i) => (
            <View key={t} style={s.tocItem}>
              <Text>{String(i + 1).padStart(2, "0")}  {t}</Text>
            </View>
          ))}
        </View>
        <Text style={s.h2}>Como ler este relatório</Text>
        <View style={s.rule} />
        <Text style={s.body}>
          Este material não é um diagnóstico nem uma previsão. Ele parte do seu nome completo e da
          sua data de nascimento para propor pontos de reflexão. Trate cada seção como uma pergunta,
          não como um veredito: onde ressoar, aprofunde; onde não fizer sentido, descarte. O valor
          está menos na resposta e mais no que ela desperta em você.
        </Text>
      </Page>

      {/* Dimensões */}
      <Page size="A4" style={s.page}>
        <Text style={s.eyebrowSmall}>As quatro dimensões</Text>
        {r.dimensions.map((d, i) => (
          <View key={i} style={s.card} wrap={false}>
            <View style={{ flexDirection: "row", alignItems: "flex-start" }}>
              <Text style={s.num}>{d.number}</Text>
              <View style={{ flex: 1 }}>
                <Text style={s.cardLabel}>{d.label} · {d.kind}</Text>
                <Text style={s.cardTitle}>{d.title}</Text>
                <Text style={s.body}>{d.description}</Text>
                <Text style={s.question}>Para refletir: {d.question}</Text>
              </View>
            </View>
          </View>
        ))}
        <Footer />
      </Page>

      {/* Potenciais e desafios + conclusão */}
      <Page size="A4" style={s.page}>
        <Text style={s.eyebrowSmall}>Potenciais e desafios</Text>
        <Text style={s.h2}>Onde a sua força também cobra um preço</Text>
        <View style={s.rule} />
        <Text style={s.body}>
          A maioria dos padrões acima funciona como uma moeda de dois lados: a mesma qualidade que
          te destaca é, no excesso, o que te trava. {r.firstName ? r.firstName + ", o" : "O"} convite
          aqui é observar em quais contextos cada traço vira vantagem e em quais vira armadilha —
          porque raramente o problema é o traço; costuma ser a dose e o momento.
        </Text>

        <View style={{ height: 24 }} />
        <Text style={s.eyebrowSmall}>Conclusão</Text>
        <Text style={s.h2}>O relatório é um espelho, não um mapa</Text>
        <View style={s.rule} />
        <Text style={s.body}>
          Você não precisa concordar com tudo o que leu. Precisa apenas ter olhado. Se alguma
          pergunta ficou incomodando depois de fechar este documento, ela cumpriu seu papel. Guarde-a.
          É por ali que costuma começar o próximo passo.
        </Text>
        <Footer />
      </Page>
    </Document>
  );
}

export async function renderReportPDF(input: ReportInput): Promise<Buffer> {
  return renderToBuffer(<ReportDoc {...input} />);
}
