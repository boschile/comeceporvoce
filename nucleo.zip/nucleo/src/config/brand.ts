// Único lugar para ajustar marca, textos institucionais e contatos.
export const brand = {
  name: "Núcleo",
  tagline: "Padrões que você talvez nunca tenha percebido.",
  domain: "seudominio.com.br",
  email: "contato@seudominio.com.br",

  // Aviso legal exibido em vários pontos.
  disclaimer:
    "O conteúdo tem finalidade exclusivamente educativa e de autoconhecimento. " +
    "Não substitui avaliação psicológica, médica ou qualquer outro serviço profissional.",

  // Como o produto se descreve (sem linguagem clínica ou mística).
  method:
    "Uma leitura estruturada a partir do seu nome completo e da sua data de " +
    "nascimento, pensada para provocar reflexão — não para diagnosticar.",

  cta: {
    primary: "Quero descobrir meu perfil",
    report: "Quero receber meu relatório completo"
  }
} as const;

export const siteUrl =
  process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "") || "http://localhost:3000";

export const whatsappNumber = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "";
