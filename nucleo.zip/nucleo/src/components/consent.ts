"use client";
import { useEffect, useState } from "react";

const KEY = "nucleo_consent"; // "granted" | "denied"
const EVENT = "nucleo-consent";

export function getConsent(): "granted" | "denied" | null {
  if (typeof window === "undefined") return null;
  const v = localStorage.getItem(KEY);
  return v === "granted" || v === "denied" ? v : null;
}

export function setConsent(value: "granted" | "denied") {
  localStorage.setItem(KEY, value);
  window.dispatchEvent(new CustomEvent(EVENT, { detail: value }));
}

export function useConsent() {
  const [consent, setState] = useState<"granted" | "denied" | null>(null);
  useEffect(() => {
    setState(getConsent());
    const handler = (e: Event) => setState((e as CustomEvent).detail);
    window.addEventListener(EVENT, handler);
    return () => window.removeEventListener(EVENT, handler);
  }, []);
  return consent;
}
