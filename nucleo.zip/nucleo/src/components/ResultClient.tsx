"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { brand } from "@/config/brand";
import { PatternVisual } from "./PatternVisual";
import { LeadForm } from "./LeadForm";
import type { Preview } from "@/lib/numerology";

export function ResultClient() {
  const params = useSearchParams();
  const leadId = params.get("lead") || "";
  const [preview, setPreview] = useState<Preview | null>(null);
  const [status, setStatus] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    if (!leadId) return setStatus("error");
    const cached = sessionStorage.getItem(`preview:${leadId}`);
    if (cached) {
      setPreview(JSON.parse(cached));
      setStatus("ready");
      return;
    }
    fetch(`/api/lead/${leadId}/preview`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j) => {
        setPreview(j.preview);
        setStatus("ready");
      })
      .catch(() => setStatus("error"));
  }, [leadId]);

  if (status === "loading") {
    return <p className="container-tight py-32 text-center text-slate-muted">Carregando sua prévia…</p>;
  }
  if (status === "error" || !preview) {
    return (
      <div className="container-tight py-32 text-center">
        <p className="text-slate-muted">Não encontramos sua análise. Ela pode ter expirado.</p>
        <Link href="/#descobrir" className="btn-primary mt-6">Refazer a análise</Link>
      </div>
    );
  }

  return (
    <div className="container-tight py-14 sm:py-20">
      {/* Cabeçalho do resultado */}
      <div className="grid items-center gap-10 lg:grid-cols-[1fr_auto]">
        <div className="reveal">
          <p className="eyebrow">Sua prévia, {preview.firstName}</p>
          <h1 className="mt-4 text-3xl leading-tight text-ink dark:text-white sm:text-4xl">
            Tivemos três descobertas importantes sobre o seu perfil.
          </h1>
          <p className="mt-4 max-w-measure text-slate-muted">
            Leia com calma. Onde ressoar, aprofunde. Onde não fizer sentido, descarte — o valor está no que a pergunta desperta.
          </p>
        </div>
        <div className="hidden justify-self-end lg:block">
          <PatternVisual numbers={preview.numbers} size={220} />
        </div>
      </div>

      {/* Os três padrões */}
      <div className="mt-14 space-y-px overflow-hidden rounded-2xl border hairline bg-hair dark:bg-white/10">
        {preview.patterns.map((p) => (
          <article key={p.index} className="bg-white p-7 dark:bg-ink-800 sm:p-9">
            <div className="flex items-start gap-5">
              <span className="font-display text-4xl text-azure sm:text-5xl">{String(p.index).padStart(2, "0")}</span>
              <div className="flex-1">
                <h2 className="text-xl text-ink dark:text-white sm:text-2xl">{p.title}</h2>
                <p className="mt-3 max-w-measure leading-relaxed text-slate-muted">{p.description}</p>
                <p className="mt-5 border-l-2 border-azure pl-4 font-display text-lg italic text-ink dark:text-slate-100">
                  {p.question}
                </p>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Fechamento de curiosidade */}
      <div className="mt-14 rounded-3xl border hairline bg-[#FAFBFC] p-8 dark:bg-ink-800/50 sm:p-12">
        <p className="max-w-measure text-lg leading-relaxed text-ink dark:text-slate-100">
          Esses são apenas alguns dos padrões encontrados. Seu relatório completo apresenta análises
          detalhadas, potenciais, desafios, ciclos, talentos e pontos de atenção.
        </p>

        <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_1fr] lg:gap-16">
          <ul className="space-y-3 text-[15px] text-slate-muted">
            {["Quatro dimensões do seu perfil", "Onde sua força vira armadilha", "Perguntas para reflexão guiada", "Enviado em PDF para o seu e-mail"].map((i) => (
              <li key={i} className="flex items-center gap-3"><Check /> {i}</li>
            ))}
          </ul>

          <div id="relatorio" className="rounded-2xl border hairline bg-white p-6 dark:bg-ink-800">
            <h3 className="font-display text-xl text-ink dark:text-white">{brand.cta.report}</h3>
            <p className="mb-5 mt-1 text-sm text-slate-muted">Sem custo. Chega no seu e-mail.</p>
            <LeadForm leadId={leadId} prefillName={preview.firstName} />
          </div>
        </div>
      </div>

      <p className="mx-auto mt-12 max-w-measure text-center text-xs leading-relaxed text-slate-muted">{brand.disclaimer}</p>
    </div>
  );
}

function Check() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#2E5AAC" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0">
      <path d="M20 6 9 17l-5-5" />
    </svg>
  );
}
