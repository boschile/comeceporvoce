import Link from "next/link";
import { brand } from "@/config/brand";
import { ThemeToggle } from "./ThemeToggle";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b hairline bg-white/80 backdrop-blur-md dark:bg-ink-900/80">
      <div className="container-tight flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 font-display text-lg text-ink dark:text-white">
          <span className="grid h-7 w-7 place-items-center rounded-full bg-ink text-[13px] text-white dark:bg-white dark:text-ink">N</span>
          {brand.name}
        </Link>
        <div className="flex items-center gap-3">
          <Link href="/#como-funciona" className="hidden text-sm text-slate-muted transition-colors hover:text-ink dark:hover:text-white sm:block">
            Como funciona
          </Link>
          <ThemeToggle />
          <Link href="/#descobrir" className="btn-primary hidden py-2.5 text-[13px] sm:inline-flex">
            Começar
          </Link>
        </div>
      </div>
    </header>
  );
}
