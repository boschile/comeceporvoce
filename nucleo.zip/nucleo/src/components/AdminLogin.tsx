"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { brand } from "@/config/brand";

export function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const res = await fetch("/api/admin/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password })
    });
    if (res.ok) {
      router.refresh();
    } else {
      const j = await res.json().catch(() => ({}));
      setError(j.error || "Falha ao entrar.");
      setLoading(false);
    }
  }

  return (
    <div className="grid min-h-screen place-items-center bg-[#FAFBFC] px-6 dark:bg-ink-900">
      <div className="w-full max-w-sm rounded-2xl border hairline bg-white p-8 shadow-xl dark:bg-ink-800">
        <p className="eyebrow">{brand.name} · Painel</p>
        <h1 className="mt-3 text-2xl text-ink dark:text-white">Acesso administrativo</h1>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <input type="password" className="field" placeholder="Senha" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus required />
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button className="btn-primary w-full disabled:opacity-60" disabled={loading}>{loading ? "Entrando…" : "Entrar"}</button>
        </form>
      </div>
    </div>
  );
}
