import Link from "next/link";
import { brand } from "@/config/brand";

export function Footer() {
  return (
    <footer className="border-t hairline bg-white dark:bg-ink-900">
      <div className="container-tight py-14">
        <div className="flex flex-col gap-8 sm:flex-row sm:items-start sm:justify-between">
          <div className="max-w-xs">
            <p className="font-display text-xl text-ink dark:text-white">{brand.name}</p>
            <p className="mt-2 text-sm leading-relaxed text-slate-muted">{brand.tagline}</p>
          </div>
          <nav className="flex flex-col gap-2 text-sm text-slate-muted">
            <Link href="/#como-funciona" className="transition-colors hover:text-ink dark:hover:text-white">Como funciona</Link>
            <Link href="/#perguntas" className="transition-colors hover:text-ink dark:hover:text-white">Perguntas frequentes</Link>
            <Link href="/privacidade" className="transition-colors hover:text-ink dark:hover:text-white">Privacidade</Link>
          </nav>
        </div>
        <div className="mt-10 border-t hairline pt-6">
          <p className="max-w-measure text-xs leading-relaxed text-slate-muted">{brand.disclaimer}</p>
          <p className="mt-4 text-xs text-slate-muted">© {new Date().getFullYear()} {brand.name}. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
