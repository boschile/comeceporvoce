"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { brand } from "@/config/brand";
import { trackLead } from "./Analytics";

export function LeadForm({ leadId, prefillName }: { leadId: string; prefillName?: string }) {
  const router = useRouter();
  const [contactName, setContactName] = useState(prefillName || "");
  const [email, setEmail] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [consent, setConsent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const honeypot = useRef<HTMLInputElement>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!consent) return setError("É preciso concordar com os termos para continuar.");
    setLoading(true);
    const eventId = `${leadId}-${Date.now()}`;
    try {
      const res = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ leadId, contactName, email, whatsapp, consent, eventId, honeypot: honeypot.current?.value })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Não foi possível concluir agora.");
      trackLead(eventId);
      router.push("/obrigado");
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <input ref={honeypot} type="text" name="website" tabIndex={-1} autoComplete="off" className="absolute -left-[9999px] h-0 w-0" aria-hidden />

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="c-name" className="mb-1.5 block text-[13px] font-medium text-slate-muted">Nome</label>
          <input id="c-name" className="field" value={contactName} onChange={(e) => setContactName(e.target.value)} autoComplete="given-name" required />
        </div>
        <div>
          <label htmlFor="c-wpp" className="mb-1.5 block text-[13px] font-medium text-slate-muted">WhatsApp</label>
          <input id="c-wpp" className="field" placeholder="(11) 90000-0000" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} inputMode="tel" autoComplete="tel" />
        </div>
      </div>
      <div>
        <label htmlFor="c-email" className="mb-1.5 block text-[13px] font-medium text-slate-muted">E-mail</label>
        <input id="c-email" type="email" className="field" placeholder="voce@email.com" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" required />
      </div>

      <label className="flex cursor-pointer items-start gap-3 text-[13px] leading-relaxed text-slate-muted">
        <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 h-4 w-4 rounded border-hair text-azure focus:ring-azure" />
        <span>
          Concordo em receber meu relatório e comunicações relacionadas, e li a{" "}
          <a href="/privacidade" target="_blank" className="text-azure underline underline-offset-2">política de privacidade</a>.
        </span>
      </label>

      {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}

      <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
        {loading ? "Enviando…" : brand.cta.report}
      </button>
      <p className="text-center text-xs text-slate-muted">Enviamos o PDF para o seu e-mail. Sem custo.</p>
    </form>
  );
}
