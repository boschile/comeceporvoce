"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { brand } from "@/config/brand";

type Lead = {
  id: string;
  stage: string;
  fullName: string;
  birthDate: string;
  contactName: string | null;
  email: string | null;
  whatsapp: string | null;
  lifePath: number;
  expression: number;
  soulUrge: number;
  personality: number;
  contacted: boolean;
  reportSentAt: string | null;
  notes: string | null;
  createdAt: string;
};

type Metrics = {
  totals: { previews: number; captured: number; reportsSent: number; contacted: number };
  rates: { captureRate: number; contactRate: number };
  series: { date: string; previews: number; captures: number }[];
};

const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

export function AdminDashboard() {
  const router = useRouter();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [q, setQ] = useState("");
  const [stage, setStage] = useState("ALL");
  const [contacted, setContacted] = useState("ALL");
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Lead | null>(null);
  const [toast, setToast] = useState("");

  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(""), 2500); };

  const load = useCallback(async () => {
    setLoading(true);
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (stage !== "ALL") p.set("stage", stage);
    if (contacted !== "ALL") p.set("contacted", contacted);
    const [lr, mr] = await Promise.all([
      fetch(`/api/admin/leads?${p}`),
      fetch("/api/admin/metrics")
    ]);
    if (lr.status === 401) return router.refresh();
    setLeads((await lr.json()).leads || []);
    setMetrics(await mr.json());
    setLoading(false);
  }, [q, stage, contacted, router]);

  useEffect(() => {
    const t = setTimeout(load, 250); // debounce da busca
    return () => clearTimeout(t);
  }, [load]);

  async function toggleContacted(l: Lead) {
    await fetch(`/api/admin/leads/${l.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contacted: !l.contacted })
    });
    load();
  }

  async function remove(l: Lead) {
    if (!confirm(`Excluir o lead "${l.fullName}"? Esta ação não pode ser desfeita.`)) return;
    await fetch(`/api/admin/leads/${l.id}`, { method: "DELETE" });
    flash("Lead excluído.");
    load();
  }

  async function resend(l: Lead) {
    flash("Reenviando…");
    const res = await fetch(`/api/admin/leads/${l.id}/resend`, { method: "POST" });
    const j = await res.json();
    flash(j.sent ? "Relatório reenviado." : "SMTP não configurado — não enviado.");
    load();
  }

  async function logout() {
    await fetch("/api/admin/session", { method: "DELETE" });
    router.refresh();
  }

  const maxSeries = useMemo(
    () => Math.max(1, ...(metrics?.series.map((s) => s.previews) || [1])),
    [metrics]
  );

  return (
    <div className="min-h-screen bg-[#FAFBFC] dark:bg-ink-900">
      <header className="border-b hairline bg-white dark:bg-ink-800">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
          <p className="font-display text-lg text-ink dark:text-white">{brand.name} · Painel</p>
          <button onClick={logout} className="btn-ghost py-2 text-[13px]">Sair</button>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-8 px-6 py-8">
        {/* Métricas */}
        <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card label="Prévias geradas" value={metrics?.totals.previews ?? "—"} />
          <Card label="Leads capturados" value={metrics?.totals.captured ?? "—"} hint={metrics ? `Captura: ${pct(metrics.rates.captureRate)}` : ""} />
          <Card label="Relatórios enviados" value={metrics?.totals.reportsSent ?? "—"} />
          <Card label="Contatados" value={metrics?.totals.contacted ?? "—"} hint={metrics ? `Follow-up: ${pct(metrics.rates.contactRate)}` : ""} />
        </section>

        {/* Série 14 dias */}
        <section className="rounded-2xl border hairline bg-white p-6 dark:bg-ink-800">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-eyebrow text-slate-muted">Últimos 14 dias</h2>
            <div className="flex gap-4 text-xs text-slate-muted">
              <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-ink dark:bg-white/70" /> prévias</span>
              <span className="flex items-center gap-1.5"><i className="inline-block h-2 w-2 rounded-full bg-azure" /> capturas</span>
            </div>
          </div>
          <div className="mt-5 flex h-28 items-end gap-1.5">
            {metrics?.series.map((s) => (
              <div key={s.date} className="group relative flex flex-1 flex-col items-center justify-end gap-0.5" title={`${s.date}: ${s.previews} prévias, ${s.captures} capturas`}>
                <div className="w-full rounded-t bg-azure" style={{ height: `${(s.captures / maxSeries) * 100}%` }} />
                <div className="w-full rounded-t bg-ink/80 dark:bg-white/40" style={{ height: `${((s.previews - s.captures) / maxSeries) * 100}%` }} />
              </div>
            ))}
          </div>
        </section>

        {/* Controles */}
        <section className="flex flex-wrap items-center gap-3">
          <input className="field max-w-xs" placeholder="Buscar por nome, e-mail, WhatsApp…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="field max-w-[170px]" value={stage} onChange={(e) => setStage(e.target.value)}>
            <option value="ALL">Todas as etapas</option>
            <option value="PARTIAL">Só prévia</option>
            <option value="CAPTURED">Capturados</option>
          </select>
          <select className="field max-w-[170px]" value={contacted} onChange={(e) => setContacted(e.target.value)}>
            <option value="ALL">Contato: todos</option>
            <option value="false">Não contatados</option>
            <option value="true">Contatados</option>
          </select>
          <a href="/api/admin/export" className="btn-ghost py-2.5 text-[13px]">Exportar CSV/Excel</a>
        </section>

        {/* Tabela */}
        <section className="overflow-x-auto rounded-2xl border hairline bg-white dark:bg-ink-800">
          <table className="w-full min-w-[860px] text-left text-sm">
            <thead className="border-b hairline text-xs uppercase tracking-wide text-slate-muted">
              <tr>
                {["Nome / contato", "Contato", "Números", "Etapa", "Criado", "Ações"].map((h) => (
                  <th key={h} className="px-4 py-3 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y hairline">
              {loading && <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-muted">Carregando…</td></tr>}
              {!loading && leads.length === 0 && <tr><td colSpan={6} className="px-4 py-10 text-center text-slate-muted">Nenhum lead ainda. Assim que alguém gerar uma prévia, aparece aqui.</td></tr>}
              {leads.map((l) => (
                <tr key={l.id} className="align-top hover:bg-[#FAFBFC] dark:hover:bg-white/[0.03]">
                  <td className="px-4 py-3">
                    <p className="font-medium text-ink dark:text-white">{l.contactName || l.fullName}</p>
                    <p className="text-xs text-slate-muted">Análise: {l.fullName} · {l.birthDate}</p>
                  </td>
                  <td className="px-4 py-3 text-slate-muted">
                    {l.email ? <p>{l.email}</p> : <span className="text-slate-muted/60">—</span>}
                    {l.whatsapp && <p className="text-xs">{l.whatsapp}</p>}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-muted">
                    CV {l.lifePath} · EX {l.expression} · AL {l.soulUrge} · PE {l.personality}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${l.stage === "CAPTURED" ? "bg-azure/10 text-azure" : "bg-slate-muted/10 text-slate-muted"}`}>
                      {l.stage === "CAPTURED" ? "Capturado" : "Prévia"}
                    </span>
                    {l.reportSentAt && <p className="mt-1 text-[10px] text-slate-muted">enviado</p>}
                  </td>
                  <td className="px-4 py-3 text-xs text-slate-muted">{new Date(l.createdAt).toLocaleDateString("pt-BR")}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
                      <label className="flex cursor-pointer items-center gap-1 text-slate-muted">
                        <input type="checkbox" checked={l.contacted} onChange={() => toggleContacted(l)} className="h-3.5 w-3.5 rounded border-hair text-azure" />
                        contatado
                      </label>
                      <button onClick={() => setEditing(l)} className="text-azure hover:underline">editar</button>
                      {l.email && <button onClick={() => resend(l)} className="text-azure hover:underline">reenviar</button>}
                      <a href={`/api/pdf?lead=${l.id}`} target="_blank" className="text-azure hover:underline">PDF</a>
                      <button onClick={() => remove(l)} className="text-red-600 hover:underline">excluir</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </main>

      {editing && <EditModal lead={editing} onClose={() => setEditing(null)} onSaved={() => { setEditing(null); flash("Lead atualizado."); load(); }} />}
      {toast && <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 text-sm text-white shadow-lg dark:bg-white dark:text-ink">{toast}</div>}
    </div>
  );
}

function Card({ label, value, hint }: { label: string; value: number | string; hint?: string }) {
  return (
    <div className="rounded-2xl border hairline bg-white p-5 dark:bg-ink-800">
      <p className="text-xs uppercase tracking-eyebrow text-slate-muted">{label}</p>
      <p className="mt-2 font-display text-3xl text-ink dark:text-white">{value}</p>
      {hint && <p className="mt-1 text-xs text-azure">{hint}</p>}
    </div>
  );
}

function EditModal({ lead, onClose, onSaved }: { lead: Lead; onClose: () => void; onSaved: () => void }) {
  const [form, setForm] = useState({
    contactName: lead.contactName || "",
    email: lead.email || "",
    whatsapp: lead.whatsapp || "",
    notes: lead.notes || ""
  });
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    await fetch(`/api/admin/leads/${lead.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    onSaved();
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-ink/40 p-4 backdrop-blur-sm" onClick={onClose}>
      <div className="w-full max-w-md rounded-2xl border hairline bg-white p-6 dark:bg-ink-800" onClick={(e) => e.stopPropagation()}>
        <h3 className="font-display text-xl text-ink dark:text-white">Editar lead</h3>
        <p className="mb-5 text-xs text-slate-muted">Análise: {lead.fullName}</p>
        <div className="space-y-3">
          {(["contactName", "email", "whatsapp"] as const).map((k) => (
            <input key={k} className="field" placeholder={k === "contactName" ? "Nome" : k === "email" ? "E-mail" : "WhatsApp"} value={(form as any)[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
          ))}
          <textarea className="field min-h-[80px]" placeholder="Anotações internas" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </div>
        <div className="mt-6 flex justify-end gap-3">
          <button onClick={onClose} className="btn-ghost py-2.5 text-[13px]">Cancelar</button>
          <button onClick={save} disabled={saving} className="btn-primary py-2.5 text-[13px]">{saving ? "Salvando…" : "Salvar"}</button>
        </div>
      </div>
    </div>
  );
}
