import type { Numbers } from "@/lib/numerology";

// Assinatura visual do produto: um diagrama radial silencioso, derivado
// dos quatro números. É deliberadamente analítico (parece um gráfico),
// nunca esotérico. Sem números? Desenha um padrão neutro de referência.
export function PatternVisual({
  numbers,
  size = 320,
  className = ""
}: {
  numbers?: Numbers;
  size?: number;
  className?: string;
}) {
  const values = numbers
    ? [numbers.lifePath, numbers.expression, numbers.soulUrge, numbers.personality]
    : [7, 4, 9, 2];

  const cx = size / 2;
  const cy = size / 2;
  const rings = values.map((v, i) => {
    const radius = 40 + i * 34;
    const norm = ((v % 9) + 1) / 10; // 0.1..1.0
    const circumference = 2 * Math.PI * radius;
    const dash = circumference * (0.35 + norm * 0.55);
    return { radius, circumference, dash, rotate: (v * 40) % 360, i };
  });

  // Ticks radiais — um por unidade do Caminho de Vida.
  const ticks = Array.from({ length: Math.max(3, values[0]) }, (_, k) => {
    const angle = (k / Math.max(3, values[0])) * Math.PI * 2 - Math.PI / 2;
    const r1 = 14;
    const r2 = 26;
    return {
      x1: cx + Math.cos(angle) * r1,
      y1: cy + Math.sin(angle) * r1,
      x2: cx + Math.cos(angle) * r2,
      y2: cy + Math.sin(angle) * r2
    };
  });

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      width={size}
      height={size}
      className={className}
      role="img"
      aria-label="Representação visual do perfil"
    >
      {rings.map((r) => (
        <circle
          key={r.i}
          cx={cx}
          cy={cy}
          r={r.radius}
          fill="none"
          stroke={r.i % 2 === 0 ? "#2E5AAC" : "#0C1A2B"}
          strokeOpacity={0.28 + r.i * 0.14}
          strokeWidth={1.4}
          strokeDasharray={`${r.dash} ${r.circumference}`}
          strokeLinecap="round"
          transform={`rotate(${r.rotate} ${cx} ${cy})`}
          className="[stroke-dashoffset:0] motion-safe:[animation:draw_1.4s_ease-out]"
        />
      ))}
      {ticks.map((t, k) => (
        <line key={k} x1={t.x1} y1={t.y1} x2={t.x2} y2={t.y2} stroke="#2E5AAC" strokeWidth={1.4} strokeLinecap="round" />
      ))}
      <circle cx={cx} cy={cy} r={4} fill="#2E5AAC" />
    </svg>
  );
}
