"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { getConsent, setConsent } from "./consent";

export function CookieBanner() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (getConsent() === null) setShow(true);
  }, []);
  if (!show) return null;

  const decide = (v: "granted" | "denied") => {
    setConsent(v);
    setShow(false);
  };

  return (
    <div className="fixed inset-x-3 bottom-3 z-50 sm:inset-x-auto sm:right-6 sm:bottom-6 sm:max-w-md reveal">
      <div className="rounded-2xl border border-hair bg-white/95 p-5 shadow-xl backdrop-blur dark:border-white/10 dark:bg-ink-800/95">
        <p className="text-sm leading-relaxed text-ink dark:text-slate-200">
          Usamos cookies para medir o desempenho do site e melhorar sua experiência. Você decide.{" "}
          <Link href="/privacidade" className="text-azure underline underline-offset-2">
            Política de privacidade
          </Link>
          .
        </p>
        <div className="mt-4 flex gap-2">
          <button onClick={() => decide("granted")} className="btn-primary flex-1 py-2.5 text-[13px]">
            Aceitar
          </button>
          <button onClick={() => decide("denied")} className="btn-ghost flex-1 py-2.5 text-[13px]">
            Recusar
          </button>
        </div>
      </div>
    </div>
  );
}
