"use client";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { brand } from "@/config/brand";

export function DataForm({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const honeypot = useRef<HTMLInputElement>(null);
  const startedAt = useRef<number>(Date.now());

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const utm = typeof window !== "undefined" ? Object.fromEntries(new URLSearchParams(window.location.search)) : {};
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName,
          birthDate,
          honeypot: honeypot.current?.value,
          startedAt: startedAt.current,
          source: document.referrer || "direct",
          utm
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Não foi possível processar agora.");
      // Carrega a prévia na próxima página sem novo round-trip.
      sessionStorage.setItem(`preview:${json.leadId}`, JSON.stringify(json.preview));
      router.push(`/resultado?lead=${json.leadId}`);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  }

  return (
    <form onSubmit={submit} className={compact ? "space-y-3" : "space-y-4"} noValidate>
      {/* honeypot invisível */}
      <input ref={honeypot} type="text" name="company" tabIndex={-1} autoComplete="off" className="absolute -left-[9999px] h-0 w-0" aria-hidden />

      <div>
        <label htmlFor="fullName" className="mb-1.5 block text-[13px] font-medium text-slate-muted">
          Nome completo
        </label>
        <input
          id="fullName"
          className="field"
          placeholder="Como está no seu registro"
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          autoComplete="name"
          required
        />
      </div>

      <div>
        <label htmlFor="birthDate" className="mb-1.5 block text-[13px] font-medium text-slate-muted">
          Data de nascimento
        </label>
        <input
          id="birthDate"
          type="date"
          className="field"
          value={birthDate}
          onChange={(e) => setBirthDate(e.target.value)}
          max={new Date().toISOString().slice(0, 10)}
          required
        />
      </div>

      {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}

      <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
        {loading ? "Analisando…" : brand.cta.primary}
      </button>
      <p className="text-center text-xs text-slate-muted">
        Gratuito · Leva menos de um minuto · Sem cadastro para ver a prévia.
      </p>
    </form>
  );
}
